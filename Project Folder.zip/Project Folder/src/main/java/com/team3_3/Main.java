package com.team3_3;

import com.google.common.hash.Hashing;

import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
    }
}
