package com.team3_3.UI;

import javafx.event.ActionEvent;

public class Controller {


    public void loginAction(ActionEvent actionEvent) {
        System.out.println("hello world");
    }

    public void forgottenAction(ActionEvent actionEvent) {
        System.out.println("hello world");
    }
}
