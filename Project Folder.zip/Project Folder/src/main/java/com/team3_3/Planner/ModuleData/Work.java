package com.team3_3.Planner.ModuleData;

public class Work {
}
